package com.example.apitry

import retrofit2.Call
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.GET
import retrofit2.http.Query

interface ApiService
{
    @GET("https://api.met.no/weatherapi/sunrise/2.0/.json")
    //fun getRequest(): Call<Request>
    fun search(@Query("lat") lat:String, @Query("lon") lon:String, @Query("date") date:String, @Query("offset") offset:String):Call<Request>
    companion object Factory {
        fun create(): ApiService {
            val retrofit = Retrofit.Builder()
                //.addConverterFactory(JaxbConverterFactory.create())
                .addConverterFactory(GsonConverterFactory.create())
                .baseUrl("https://api.met.no/")
                .build()

            return retrofit.create(ApiService::class.java);
        }
    }
}