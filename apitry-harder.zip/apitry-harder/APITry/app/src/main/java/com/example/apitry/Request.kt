package com.example.apitry
data class Request(val location:Location)
{
    class Location(val time:List<CurTime>, val latitude:Float, val longitude:Float, val height:Float)
    class CurTime(val date:String, val sunrise:TimeOf, val sunset:TimeOf, val solarnoon:TimeOf, val solarmidnight:TimeOf,
                  val moonphase:TimeOf, val moonshadow:TimeOf, val moonposition:TimeOf, val moonrise:TimeOf, val moonset:TimeOf,
                  val high_moon:TimeOf, val low_moon:TimeOf, val polardayend:TimeOf, val polardaystart:TimeOf, val polarnightend:TimeOf, val polarnightstart:TimeOf)
    open class TimeOf(val time:String, val value:Float?, val elevation:Float?, val azimuth:Float?, val desc:String, val phase:Float?, val range:Float?)
}

data class Result (val total_count: Int, val incomplete_results: Boolean, val items: List<Request>)